create definer = root@localhost trigger new_user_history
    after insert
    on users
    for each row
    insert into user_history (user_id) values (NEW.id);

