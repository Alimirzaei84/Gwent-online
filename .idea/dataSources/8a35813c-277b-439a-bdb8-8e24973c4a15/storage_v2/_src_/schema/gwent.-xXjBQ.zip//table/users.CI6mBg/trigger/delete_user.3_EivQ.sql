create definer = root@localhost trigger delete_user
    before delete
    on users
    for each row
BEGIN
        DELETE FROM user_deck WHERE user_id = OLD.id;
        DELETE FROM user_history WHERE user_id = OLD.id;
    end;

